let secondsWatched = 0;
let platformName = "Unknown";
let isCurrentlyTracking = false; // Added to control the icon badge
const hostname = window.location.hostname;

// 1. Identify the Platform
if (hostname.includes("netflix")) platformName = "Netflix";
else if (hostname.includes("primevideo") || hostname.includes("amazon")) platformName = "Prime Video";
else if (hostname.includes("hotstar")) platformName = "Disney+ Hotstar";
else if (hostname.includes("jiocinema")) platformName = "JioCinema";
else if (hostname.includes("sonyliv")) platformName = "SonyLIV";
else if (hostname.includes("zee5")) platformName = "ZEE5";
else if (hostname.includes("crunchyroll")) platformName = "Crunchyroll";
else if (hostname.includes("airtelxstream.in")) platformName = "Airtel Xstream";

console.log(`🚀 SubSavvy AI loaded on ${platformName}. Using Enterprise Media API...`);

// 2. Advanced Title Scraper
function getShowTitle() {
    let rawTitle = "";

    // STRATEGY A: The MediaSession API
    if (navigator.mediaSession?.metadata?.title) {
        rawTitle = navigator.mediaSession.metadata.title;
    }

    // STRATEGY B: The DOM Fallback
    if (!rawTitle && platformName === "Airtel Xstream") {
        const titleElement = document.querySelector('.content-tag-title .title');
        if (titleElement) rawTitle = titleElement.innerText;
    }

    // STRATEGY C: The Tab Title Fallback
    if (!rawTitle) {
        rawTitle = document.title;
    }

    return cleanTitle(rawTitle);
}

// Universal Title Cleaner
function cleanTitle(title) {
    if (!title) return "Unknown Title";
    
    let clean = title;
    clean = clean.replace(/\| Netflix/gi, "");
    clean = clean.replace(/Prime Video:/gi, "");
    clean = clean.replace(/Watch/gi, "");
    clean = clean.replace(/Full Episode/gi, "");
    clean = clean.replace(/- JioCinema/gi, "");
    clean = clean.replace(/Streaming Online/gi, "");
    clean = clean.replace(/on Disney\+ Hotstar/gi, "");
    clean = clean.replace(/SonyLIV/gi, "");
    clean = clean.replace(/ZEE5/gi, "");
    clean = clean.replace(/Crunchyroll/gi, "");
    clean = clean.replace(/Airtel Xstream Play/gi, "");
    clean = clean.replace(/TV Show Latest Episodes Online at.*/gi, "");
    
    return clean.replace(/^[\s\|\-]+|[\s\|\-]+$/g, '').trim() || "Unknown Title";
}

// 3. The Tracker Loop
const trackerInterval = setInterval(() => {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
        clearInterval(trackerInterval);
        return;
    }

    let isPlaying = false;

    // STRATEGY A: Use OS-Level Media API
    if (navigator.mediaSession?.playbackState === "playing") {
        isPlaying = true;
    } 
    
    // STRATEGY B: Check local DOM video tags
    if (!isPlaying) {
        const videoElements = document.querySelectorAll('video');
        videoElements.forEach((vid) => {
            if (vid && !vid.paused && !vid.ended && vid.readyState > 2) {
                isPlaying = true;
            }
        });
    }

    if (isPlaying && platformName !== "Unknown") {
        // --- TURN ON THE REC BADGE ---
        if (!isCurrentlyTracking) {
            isCurrentlyTracking = true;
            chrome.runtime.sendMessage({ action: "tracking_started" });
        }

        secondsWatched += 10;
        const currentTitle = getShowTitle();
        
        console.log(`▶️ Tracking ${platformName}: "${currentTitle}"... (${secondsWatched}s)`);

        if (secondsWatched >= 60) {
            try {
                let messagePromise = chrome.runtime.sendMessage({ 
                    action: "log_minute", 
                    platform: platformName,
                    title: currentTitle 
                });
                
                if (messagePromise) {
                    messagePromise.catch(() => clearInterval(trackerInterval));
                }
                secondsWatched = 0; 
            } catch (err) {
                clearInterval(trackerInterval);
            }
        }
    } else {
        // --- TURN OFF THE REC BADGE WHEN PAUSED ---
        if (isCurrentlyTracking) {
            isCurrentlyTracking = true; // Wait, we want to set it to false! Let's correct this:
            isCurrentlyTracking = false;
            chrome.runtime.sendMessage({ action: "tracking_stopped" });
        }
    }
}, 10000);