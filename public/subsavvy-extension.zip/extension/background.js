const API_URL = "https://subsavvy-backend.onrender.com";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // 1. Manage the Dynamic "REC" Badge on the Icon
    if (request.action === "tracking_started") {
        if (sender.tab && sender.tab.id) {
            chrome.action.setBadgeText({ text: "REC", tabId: sender.tab.id });
            chrome.action.setBadgeBackgroundColor({ color: "#d946ef", tabId: sender.tab.id }); // Fuchsia
        }
        sendResponse({ success: true });
    } 
    else if (request.action === "tracking_stopped") {
        if (sender.tab && sender.tab.id) {
            chrome.action.setBadgeText({ text: "", tabId: sender.tab.id });
        }
        sendResponse({ success: true });
    }

    // 2. Log the actual minute to the backend
    else if (request.action === "log_minute") {
        
        // Grab the user's secure token from Chrome's local storage
        chrome.storage.local.get(['access_token'], async (result) => {
            if (!result.access_token) {
                console.log("SubSavvy: No access token found. Please log in via the extension popup.");
                sendResponse({ success: false, error: "Not logged in" });
                return;
            }

            try {
                // Send the ping to our live FastAPI backend
                const response = await fetch(`${API_URL}/usage/extension`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${result.access_token}`
                    },
                    body: JSON.stringify({
                        platform_name: request.platform,
                        minutes_used: 1,
                        date_logged: new Date().toISOString().split('T')[0],
                        title: request.title // <-- THE CRUCIAL PIECE FOR THE AI BRAIN!
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    console.log(`SubSavvy: Logged 1 min for ${request.platform}. Title: "${request.title}"`);
                    sendResponse({ success: true });
                } else {
                    const errorText = await response.text();
                    console.error("SubSavvy: Failed to log time to backend.", errorText);
                    sendResponse({ success: false, error: errorText });
                }
            } catch (error) {
                console.error("SubSavvy API Connection Error:", error);
                sendResponse({ success: false, error: error.toString() });
            }
        });

        // Required in Manifest V3 to keep the message channel open for async fetch responses
        return true; 
    }
});