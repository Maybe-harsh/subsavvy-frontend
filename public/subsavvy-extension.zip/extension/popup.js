document.addEventListener('DOMContentLoaded', () => {
  const loginContainer = document.getElementById('login-container');
  const loggedInContainer = document.getElementById('logged-in-container');
  const loginForm = document.getElementById('login-form');
  const logoutBtn = document.getElementById('logout-btn');
  const dashboardBtn = document.getElementById('dashboard-btn');
  const statusDiv = document.getElementById('status');
  const submitBtn = document.getElementById('submit-btn');

  // 1. Check if the user is already logged in
  chrome.storage.local.get(['access_token'], (result) => {
    if (result.access_token) {
      loginContainer.classList.add('hidden');
      loggedInContainer.classList.remove('hidden');
    }
  });

  // 2. Handle the Login Form Submission
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Update UI to show loading state
    submitBtn.textContent = "Authenticating...";
    submitBtn.style.opacity = "0.7";
    statusDiv.classList.add('hidden');

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
      const formData = new URLSearchParams();
      formData.append('username', email);
      formData.append('password', password);

      // Pointing to the live Render backend
      const response = await fetch('https://subsavvy-backend.onrender.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData
      });

      if (!response.ok) {
        throw new Error('Invalid email or password');
      }

      const data = await response.json();
      
      // Save the token securely in Chrome's vault
      chrome.storage.local.set({ access_token: data.access_token }, () => {
        submitBtn.textContent = "Success!";
        
        // Smooth transition to logged-in view
        setTimeout(() => {
            loginContainer.classList.add('hidden');
            loggedInContainer.classList.remove('hidden');
        }, 800);
      });

    } catch (error) {
      statusDiv.textContent = error.message;
      statusDiv.className = "error";
      statusDiv.classList.remove('hidden');
    } finally {
      if(submitBtn.textContent !== "Success!") {
        submitBtn.textContent = "Sign In";
      }
      submitBtn.style.opacity = "1";
    }
  });

  // 3. Handle the Logout Button
  logoutBtn.addEventListener('click', () => {
    chrome.storage.local.remove(['access_token'], () => {
      // Reset the UI back to the login screen
      loginContainer.classList.remove('hidden');
      loggedInContainer.classList.add('hidden');
      document.getElementById('email').value = '';
      document.getElementById('password').value = '';
      statusDiv.classList.add('hidden');
      submitBtn.textContent = "Sign In";
    });
  });

  // 4. Handle Quick Dashboard Access
  dashboardBtn.addEventListener('click', () => {
      // Pointing directly to your live Vercel frontend
      chrome.tabs.create({ url: 'https://subsavvy-frontend-virid.vercel.app/dashboard' });
  });
});